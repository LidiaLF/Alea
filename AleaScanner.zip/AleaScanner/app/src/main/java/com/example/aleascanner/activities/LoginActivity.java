package com.example.aleascanner.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.aleascanner.R;
import com.example.aleascanner.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {
ActivityLoginBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                permisos();
            }
        });
    }


    public void enter(){
        Intent i = new Intent(LoginActivity.this, QrScannActivity.class);
        startActivity(i);
    }
    public void permisos(){
        if (Build.VERSION.SDK_INT>=23){
            int permiso1 = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            int permiso2 = checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
            int permiso3 = checkSelfPermission(Manifest.permission.VIBRATE);
            int permiso4 = checkSelfPermission(Manifest.permission.INTERNET);
            if (permiso1 == PackageManager.PERMISSION_GRANTED &
                    permiso2 == PackageManager.PERMISSION_GRANTED &
                    permiso3 == PackageManager.PERMISSION_GRANTED &
                    permiso4 == PackageManager.PERMISSION_GRANTED){
                enter();
            }
            else{
                this.requestPermissions( new String[]{ Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE,  Manifest.permission.VIBRATE,
                        Manifest.permission.INTERNET}, 1);
            }

        }else {
            enter();
        }

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enter();

            } else {
                Toast.makeText(this, R.string.needPermission, Toast.LENGTH_LONG).show();
                permisos();
            }
        }

    }
}