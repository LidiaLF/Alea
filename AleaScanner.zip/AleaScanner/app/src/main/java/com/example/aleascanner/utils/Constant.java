package com.example.aleascanner.utils;

public class Constant {
    public static final String NODO_USERS = "users" ;
    public static final String NODO_SIGN = "signings";
    public static final String ALEA = "alea";
    public static final String U_ISWORKING = "isWorking" ;
}
