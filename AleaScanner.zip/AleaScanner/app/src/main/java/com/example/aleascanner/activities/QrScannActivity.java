package com.example.aleascanner.activities;

import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.SurfaceHolder;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.aleascanner.R;
import com.example.aleascanner.databinding.ActivityQrScannBinding;
import com.example.aleascanner.databinding.DesignSnackResultBinding;
import com.example.aleascanner.utils.Constant;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class QrScannActivity extends AppCompatActivity {
    Snackbar snackbar;
    BarcodeDetector barcodeDetector;
    CameraSource cameraSource;
    DesignSnackResultBinding bindingSnack;
    ActivityQrScannBinding binding;
    String type = "";
    boolean isWorking = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityQrScannBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT > 22) {
                if (shouldShowRequestPermissionRationale(android.Manifest.permission.CAMERA))
                    Toast.makeText(getApplicationContext(), R.string.needPermission, Toast.LENGTH_SHORT).show();
                requestPermissions(new String[]{android.Manifest.permission.CAMERA}, 1);
            }
        }

        //Creamos o lector de QR
        barcodeDetector = new BarcodeDetector.Builder(this)
                .setBarcodeFormats(Barcode.QR_CODE)
                .build();

        //Creamos a cámara
        cameraSource = new CameraSource
                .Builder(this, barcodeDetector)
                .build();


        // Prepara o lector QR para recibir chamadas e inicia
        binding.cameraView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(@NonNull SurfaceHolder holder) {

                if (ContextCompat.checkSelfPermission(getBaseContext(), android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    try {
                        cameraSource.start(binding.cameraView.getHolder());
                    } catch (IOException ie) {
                        Log.e("CAMERA SOURCE", Objects.requireNonNull(ie.getMessage()));
                    }
                }
            }

            @Override
            public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {
            }

            @Override
            public void surfaceDestroyed(@NonNull SurfaceHolder holder) {
                cameraSource.stop();
            }
        });

        //Procesa o código detectado
        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {
            }

            @Override
            public void receiveDetections(Detector.Detections detections) {
                final SparseArray barcodes = detections.getDetectedItems();
                if(snackbar != null){
                   if(!snackbar.isShown()){
                       scanning(barcodes);
            }
            }else{
                    scanning(barcodes);
                }
            }
        });
        }
        private void scanning(SparseArray<Barcode> barcodes){
            if (barcodes.size() != 0) {
                /*
                *  ESTRUCTURA DE Qr VALIDA:
                *                alea-uidUser-data-E-hora
                *   // nova version
                *           alea-uidUser-ano/mes-E-dia_hora
                *           q0  - q1    - q2     - q3    - q4
                * */

                final String[] qr = barcodes.valueAt(0).displayValue.split("-");
                if (qr[0].equals(Constant.ALEA)) {
                    switch (qr[3]){
                        case "E":
                            type = "Entrada: ";
                            isWorking = true;
                            break;
                        case "S":
                            type = "Saída: ";
                            isWorking = false;
                            break;
                        case "D1":
                            type = "Inicio Descanso: ";
                            isWorking = false;
                            break;
                        case "D0":
                            type = "Fin Descanso: ";
                            isWorking = true;
                                break;
                    }

                    String[] data = qr[2].split("/");
                    String[] info = qr[4].split("_");

                    Map<String, Object> sign = new HashMap<>();
                    sign.put(qr[4], qr[3]);
                    showSnackBar(getString(R.string.user)+ " " + qr[1] + "\n\t" + type + "\n\t\t"+ info[0] + "/"+qr[2] + "\t" + info[1]);
                    FirebaseFirestore.getInstance()
                            .collection(Constant.NODO_SIGN)
                            .document(qr[1])
                            .collection(data[1])
                            .document(data[0])
                            .set(sign, SetOptions.merge()).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {

                            Map<String, Object> data = new HashMap<>();
                            data.put(Constant.U_ISWORKING, isWorking);
                            FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).document(qr[1]).set(data, SetOptions.merge()).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(QrScannActivity.this, R.string.saved, Toast.LENGTH_LONG).show();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.e("onFailure set data", e.getMessage());
                                }
                            });



                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(QrScannActivity.this, R.string.notSaved, Toast.LENGTH_LONG).show();
                            barcodeDetector.release();
                        }
                    });
                }
            }

        }
    private void showSnackBar(final String barcodes) {
        snackbar = Snackbar.make(binding.cameraView, "", Snackbar.LENGTH_LONG);
        Snackbar.SnackbarLayout layout = (Snackbar.SnackbarLayout) snackbar.getView();
        View snackView = View.inflate(this, R.layout.design_snack_result, null);
        bindingSnack = DesignSnackResultBinding.bind(snackView);
        bindingSnack.tvQrResult.post(new Runnable() {
                        public void run() {

                           bindingSnack.tvQrResult.setText(barcodes);
                        }
                    });
        layout.setPadding(10, 10, 10, 20);
        layout.setBackgroundColor(Color.parseColor("#80FFFFFF"));
        layout.addView(snackView, 0);

        snackbar.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        disconnet();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        disconnet();
    }

    public void disconnet(){
        barcodeDetector.release();
    }
}