package com.example.alea.fragment.calendar;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.alea.R;
import com.example.alea.activity.AddEventActivity;
import com.example.alea.databinding.FragmentCalendarBinding;
import com.example.alea.model.Event;
import com.example.alea.service.Service;
import com.example.alea.service.ServiceUser;
import com.example.alea.util.Constant;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class CalendarFragment extends Fragment {

    private static final String KEY_YEAR = "year";
    private static final String KEY_MONTH = "month";
    private static final String KEY_DAY = "day";
    int selecDay, selecYear, selecMonth;
    FragmentCalendarBinding binding;
    ArrayList<Event> events;
    String uid;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        Service.getInstance().loadLanguage(getContext());
        uid = ServiceUser.getInstance().getKeyCurrentUser(getContext());

        final View root = inflater.inflate(R.layout.fragment_calendar, container, false);

        binding =  FragmentCalendarBinding.bind(root);
        assert getParentFragment() != null;
        final FloatingActionButton fab = Objects.requireNonNull(getParentFragment().getActivity()).findViewById(R.id.fab);
        fab.show();

        events = new ArrayList<>();
        getToday();

        binding.calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, final int year, final int month,
                                            final int dayOfMonth) {
                selecDay = dayOfMonth;
                selecMonth = month;
                selecYear = year;
                listEvent();
            }
        });

        binding.btAddCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), AddEventActivity.class);
                i.putExtra(KEY_YEAR, selecYear);
                i.putExtra(KEY_MONTH, selecMonth);
                i.putExtra(KEY_DAY, selecDay);
                startActivity(i);
            }
        });


        return root;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void listEvent() {
        events.clear();
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        binding.recyclerCalendar.addItemDecoration(new DividerItemDecoration(Objects.requireNonNull(getContext()), DividerItemDecoration.VERTICAL));
        binding.recyclerCalendar.setLayoutManager(layoutManager);

       FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).document(uid)
                .collection(Constant.NODO_CALENDAR)
                                        .whereEqualTo(Constant.C_YEAR, selecYear)
                                        .whereEqualTo(Constant.C_MONTH, selecMonth +1)
                                        .whereEqualTo(Constant.C_DAY, selecDay)
               .get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {

                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for(DocumentSnapshot d : queryDocumentSnapshots.getDocuments()){

                            events.add(new Event(
                                                d.getId(),
                                                Integer.parseInt(d.get(Constant.C_DAY).toString()),
                                                Integer.parseInt(d.get(Constant.C_MONTH).toString()),
                                                Integer.parseInt(d.get(Constant.C_YEAR).toString()),
                                                d.get(Constant.C_TIME).toString(),
                                                d.get(Constant.C_TITLE).toString(),
                                                d.get(Constant.C_DESCRIPTION).toString(),
                                                Boolean.parseBoolean(d.get(Constant.C_REMEMBER).toString())));
                        }
                       CalendarViewHolder adapter = new CalendarViewHolder(events, new CalendarViewHolder.ListItemClickListener() {
                            @Override
                            public void onListItemClick(int itemClick) {
                                showEvent(itemClick);
                            }
                        });
                        binding.recyclerCalendar.setAdapter(adapter);
                    }
                }).addOnFailureListener(new OnFailureListener() {
           @Override
           public void onFailure(@NonNull Exception e) {
               Toast.makeText(getContext(), R.string.noPosible + "\n" + e.getMessage(), Toast.LENGTH_LONG).show();
           }
       });
    }

    private void showEvent(final int itemClick) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(events.get(itemClick).getTitle());
        builder.setIcon(R.drawable.ic_calendar);
        builder.setMessage(events.get(itemClick).getDescription());
        builder.setPositiveButton(R.string.acept, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.setNegativeButton(R.string.guess, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).document(uid)
                        .collection(Constant.NODO_CALENDAR).document(events.get(itemClick).getId()).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onSuccess(Void aVoid) {
                       listEvent();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
        builder.create().show();
    }

    public void getToday(){
         SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
         final String selectedDate = sdf.format(new Date(binding.calendarView.getDate()));
         String[] stringDate = selectedDate.split("/");
         for(int i = 0; i<stringDate.length; i++ ){
             if(i == 0){
                 selecDay = Integer.parseInt(stringDate[0]);
             }
             if(i == 1){
                 selecMonth = Integer.parseInt(stringDate[1]) -1;
             }
             if(i == 2){
                 selecYear = Integer.parseInt(stringDate[2]);
             }
         }
     }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onResume() {
        super.onResume();
        listEvent();
    }
}