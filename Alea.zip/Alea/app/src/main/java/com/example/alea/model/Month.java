package com.example.alea.model;

import java.util.ArrayList;

public class Month {
    ArrayList<Day> days;

    public Month(ArrayList<Day> days) {
        this.days = days;
    }

    @Override
    public String toString() {
        return "Month{" +
                "days=" + days +
                '}';
    }
}
