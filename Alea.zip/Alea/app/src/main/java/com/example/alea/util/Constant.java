package com.example.alea.util;

public class Constant {
    public static final String NODO_USERS = "users";
    public static final String U_UID = "uid";
    public static final String U_NAME= "name";
    public static final String U_SURNAME = "surname";
    public static final String U_DNI = "dni";
    public static final String U_JOURNEY = "journey";
    public static final String U_PHONE = "phone";
    public static final String U_EMAIL = "email";
    public static final String U_PWD = "pwd";
    public static final String U_ISWORKING = "isWorking";


    public static final String NODO_CALENDAR = "calendar";
    public static final String C_DAY= "day";
    public static final String C_MONTH = "month";
    public static final String C_YEAR = "year";
    public static final String C_TIME = "time";
    public static final String C_TITLE = "title";
    public static final String C_DESCRIPTION = "description";
    public static final String C_REMEMBER = "remember";


    public static final String NODO_SIGNS = "signings";



    public static final String NODO_MESSAGES = "messages";


    public static final String urlFoto = "fotos/perfil";


    public static final String ALEA_SP = "AleaPreferences" ;
    public static final String SP_UID = "uid" ;
    public static final String SP_PWD = "pwd";
    public static final String SP_USER = "user";
    public static final String SP_NAME = "myName";
    public static final String SP_SURNAME = "mySurname";
    public static final String SP_ISWORKING = "isWorking";

    public static final String KEY_ID =  "key_receptor";
    public static final String KEY_NAME = "nameUser";
    public static final String KEY_TLF = "tlf";
    public static final String KEY_EMAIL = "email";

    public static final String URL_SIGNS = "/ALEA_FICHAXES/";
    public static final String CONTROL_CODE = "alea-";

    public static final String SIGNS_SP = "signs" ;
    public static final String SP_K_START = "E";
    public static final String SP_K_BREAK = "D";
    public static final String SP_K_BREAK1 = "D1";
    public static final String SP_K_BREAK0 = "D0";
    public static final String SP_K_END = "S";


}
