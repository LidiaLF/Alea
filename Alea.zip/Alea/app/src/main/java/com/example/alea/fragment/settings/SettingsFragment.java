package com.example.alea.fragment.settings;

import androidx.annotation.RequiresApi;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.alea.R;
import com.example.alea.databinding.FragmentSettingsBinding;

import com.example.alea.adapter.GlideApp;
import com.example.alea.model.Employee;
import com.example.alea.service.Service;
import com.example.alea.util.Constant;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

public class SettingsFragment extends Fragment {
    private FragmentSettingsBinding binding;
    Uri ruta;
    boolean isPicture;
    FirebaseStorage storage;
    StorageReference sr;
    String uid;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSettingsBinding.inflate(getLayoutInflater());
        final FloatingActionButton fab = getParentFragment().getActivity().findViewById(R.id.fab);
        fab.show();
        storage = FirebaseStorage.getInstance();

        loadData();

        binding.ivMyPicture.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
            @Override
            public void onClick(View view) {
                loadImage();
            }
        });
        binding.btSaveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveChanges();
            }
        });

        return  binding.getRoot();
}


    public void loadData(){
        uid = getContext().getSharedPreferences(Constant.ALEA_SP, Context.MODE_PRIVATE).getString(Constant.SP_UID, "");
        storage = FirebaseStorage.getInstance();

        FirebaseStorage.getInstance().getReference().child(uid).child(Constant.urlFoto).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                String downloadUrl = uri.toString();
                assert binding.ivMyPicture != null;
                GlideApp.with(getActivity()).load(downloadUrl).diskCacheStrategy(DiskCacheStrategy.NONE).skipMemoryCache(true).into(binding.ivMyPicture);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
        FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).document(uid).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot ds) {
                binding.etName.setText(ds.get(Constant.U_NAME).toString());
                binding.etSurname.setText(ds.get(Constant.U_SURNAME).toString());
                binding.etMyEmail.setText(ds.get(Constant.U_EMAIL).toString());
                binding.etMyPhone.setText(ds.get(Constant.U_PHONE).toString());
            }
        });
    }


    private void saveChanges() {
        binding.rlLoadSettings.setVisibility(View.VISIBLE);
        if(isPicture){
            if(ruta !=null){
                sr = storage.getReference().child(uid +"/" + Constant.urlFoto);
                sr.putFile(ruta).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        binding.rlLoadSettings.setVisibility(View.GONE);
                        Toast.makeText(getContext(), R.string.savedChanges, Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        binding.rlLoadSettings.setVisibility(View.GONE);
                        Toast.makeText(getContext(), getString(R.string.noPosible) + "\n" + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        }else{
            binding.rlLoadSettings.setVisibility(View.GONE);
        }

        Map<String, Object> data = new HashMap<>();
        data.put(Constant.U_PHONE, binding.etMyPhone.getText().toString());
        FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).document(uid).set(data, SetOptions.merge()).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                binding.rlLoadSettings.setVisibility(View.GONE);
                Toast.makeText(getContext(), R.string.savedChanges, Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                binding.rlLoadSettings.setVisibility(View.GONE);
                Toast.makeText(getContext(), R.string.noPosible, Toast.LENGTH_LONG).show();
            }
        });
    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
    private void loadImage() {
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        i.setType("image/");
        startActivityForResult(i.createChooser(i, getString(R.string.selectType)),1);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        isPicture = false;
        if(resultCode == getActivity().RESULT_OK){
            if (data != null) {
                ruta = data.getData();
            }
            GlideApp.with(this).load(ruta).diskCacheStrategy(DiskCacheStrategy.NONE).skipMemoryCache(true).into(binding.ivMyPicture);
            isPicture = true;
        }
}
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onResume() {
        super.onResume();
        Service.getInstance().loadLanguage(getContext());
    }
}