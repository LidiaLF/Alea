package com.example.alea.activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.alea.R;
import com.example.alea.adapter.GlideApp;
import com.example.alea.databinding.ActivityMessageBinding;
import com.example.alea.service.ServiceUser;
import com.example.alea.util.Constant;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;

public class MessageActivity extends AppCompatActivity {
    ActivityMessageBinding binding;
    String name, phone, email, uid;
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMessageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //Flecha back toolbar
        setSupportActionBar(binding.toolbarMessage);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        binding.toolbarMessage.getNavigationIcon().setColorFilter(getResources().getColor(R.color.textWhite), PorterDuff.Mode.SRC_ATOP);

        uid = getIntent().getExtras().getString(Constant.KEY_ID);
        name =  getIntent().getExtras().getString(Constant.KEY_NAME);
        phone = getIntent().getExtras().getString(Constant.KEY_TLF);
        email = getIntent().getExtras().getString(Constant.KEY_EMAIL);

        ServiceUser.getInstance().loadImage(uid, MessageActivity.this, binding.ivReceptorImage);

        binding.tvReceptorName.setText(name);

    }


    public void onClick(View view) {
        switch (view.getId()){
            case R.id.iv_call:
                callPhone(phone);
                break;
            case R.id.iv_email:
                sendEmail();
                break;
            case R.id.bt_selectDoc:
                selectDoc();
                break;
            case R.id.bt_sendMessage:
                Toast.makeText(MessageActivity.this, "ENVIADO", Toast.LENGTH_LONG).show();
                break;
        }
    }

    public void sendEmail(){
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }


    public void callPhone(String phone){
        Intent i = new Intent(Intent.ACTION_DIAL);
        i.setData(Uri.parse("tel:" + phone));
        startActivity(i);
    }

    public void selectDoc(){
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        Intent i = Intent.createChooser(intent, "View Default File Manager");
        startActivityForResult(i, 1);
    }





    /*
     *
     * FLECHA BACK Toolbar
     * */
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }
}