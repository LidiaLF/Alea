package com.example.alea.model;

public class Message {
        private String message;
        private String urlPicture;
        private boolean isPicture;
        private String keyEmisor;

        public Message() {
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getUrlPicture() {
            return urlPicture;
        }

        public void setUrlPicture(String urlPicture) {
            this.urlPicture = urlPicture;
        }

        public boolean isPicture() {
            return isPicture;
        }

        public void setPicture(boolean picture) {
            this.isPicture = picture;
        }

        public String getKeyEmisor() {
            return keyEmisor;
        }

        public void setKeyEmisor(String keyEmisor) {
            this.keyEmisor = keyEmisor;
        }


}
