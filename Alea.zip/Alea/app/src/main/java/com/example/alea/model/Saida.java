package com.example.alea.model;

public class Saida {
    String saida;

    public Saida(String saida) {
        this.saida = saida;
    }

    @Override
    public String toString() {
        return "Saida{" +
                "saida='" + saida + '\'' +
                '}';
    }
}
