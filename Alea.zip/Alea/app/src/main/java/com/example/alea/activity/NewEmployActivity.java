package com.example.alea.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.alea.R;
import com.example.alea.databinding.ActivityNewEmployBinding;
import com.example.alea.model.Employee;
import com.example.alea.service.Service;
import com.example.alea.service.ServiceUser;
import com.example.alea.util.Constant;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;


public class NewEmployActivity extends AppCompatActivity {
    private static final String ACTION = "action";
    private static final String USR_EDIT = "user_edit";
    FirebaseFirestore db;
    ActivityNewEmployBinding binding;
    double journey = 00.00;
    Employee editEmployee;
    String title, uid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = FirebaseFirestore.getInstance();
        title =  getIntent().getExtras().getString(ACTION);
        editEmployee = (Employee) getIntent().getSerializableExtra(USR_EDIT);
        binding = ActivityNewEmployBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.tvToolTitle2.setText(title);
        if(title.equals(getString(R.string.editEmploy))){
            fillDataEmployee();
        }
         uid = ServiceUser.getInstance().getKeyCurrentUser(NewEmployActivity.this);
    }
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.iv_close2:
                alertDialog();
                break;
            case R.id.iv_save2:
              if(isDataFill()){
                  if(title.equals(getString(R.string.editEmploy))){
                      editEmployee();
                  }else{
                    saveEmployee();
                  }
                }else{
                    Toast.makeText(getApplicationContext(), R.string.needFillData, Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.rb_part_time:
                binding.etHours.setEnabled(true);
                journey = Double.parseDouble(binding.etHours.getText().toString());
                break;
            case  R.id.rb_full:
                binding.etHours.setEnabled(false);
                journey = 40.00;
                break;
            case R.id.tv_changePwd:
                FirebaseAuth.getInstance().sendPasswordResetEmail(binding.etEmailNew.getText().toString())
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(getApplicationContext(), R.string.newPwdSend, Toast.LENGTH_LONG).show();

                            }
                        }
                    });
               break;
        }
    }

    private void fillDataEmployee() {
        binding.tvChangePwd.setVisibility(View.VISIBLE);
        binding.tvChangePwd.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
        binding.etNewName.setText(editEmployee.getName());
        binding.etNewSurname.setText(editEmployee.getSurname());
        binding.etNewDni.setText(editEmployee.getDni());
        binding.etPhoneNew.setText(editEmployee.getPhone());
        binding.etEmailNew.setText(editEmployee.getEmail());
        binding.etEmailNew.setEnabled(false);
        if(editEmployee.getHoursContract() == 40.00){
            binding.rbFull.setChecked(true);
        }else{
            binding.rbPartTime.setChecked(true);
            binding.etHours.setText(editEmployee.getHoursContract()+"");
        }

    }

    private boolean isDataFill() {
        if(binding.etNewName.getText().toString().isEmpty())
            return  false;
        if(binding.etNewSurname.getText().toString().isEmpty())
            return false;
        if(binding.etNewDni.getText().toString().isEmpty())
            return false;
        if(binding.etPhoneNew.getText().toString().isEmpty())
            return false;
        if(binding.rbFull.isChecked()){
            journey = 40.00;
        }
        if(binding.rbPartTime.isChecked()){
            journey = Double.parseDouble(binding.etHours.getText().toString());
        }
        if(journey == 00.00)
            return false;
        if(binding.etEmailNew.getText().toString().isEmpty())
            return  false;
        return true;
    }

    private void saveEmployee() {
        /*
         * CREA O USUARIO AUTH
         * */
        final String pwd = "123456"; //contraseña inicial
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(binding.etEmailNew.getText().toString(), pwd)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull final Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            /*
                            * GARDA OS DATOS NA BD Cloud Firestore
                            * */
                            Map<String, Object> user = new HashMap<>();
                            user.put(Constant.U_NAME, binding.etNewName.getText().toString());
                            user.put(Constant.U_SURNAME, binding.etNewSurname.getText().toString());
                            user.put(Constant.U_DNI, binding.etNewDni.getText().toString());
                            user.put(Constant.U_EMAIL, binding.etEmailNew.getText().toString());
                            user.put(Constant.U_PWD, pwd);
                            user.put(Constant.U_JOURNEY, journey);
                            user.put(Constant.U_ISWORKING, false);
                            user.put(Constant.U_PHONE, binding.etPhoneNew.getText().toString());
                            db.collection(Constant.NODO_USERS).document(task.getResult().getUser().getUid()).set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    /*
                                    *  ENVIA UN EMAIL ao novo usuario para o cambio de contrasinal
                                    * */

                            FirebaseAuth.getInstance().sendPasswordResetEmail(binding.etEmailNew.getText().toString())
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                Toast.makeText(getApplicationContext(), R.string.registred, Toast.LENGTH_LONG).show();

                                            }
                                        }
                                    });
                            finish(); //onSucess
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(getApplicationContext(), getString(R.string.noDataSaved) + "\n" +e.getMessage(),
                                            Toast.LENGTH_LONG).show();
                                }
                            });


                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(getApplicationContext(), getString(R.string.noRegistred) + "\n" +task.getException().getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });


    }

    public void editEmployee(){
        Map<String, Object> user = new HashMap<>();
        user.put(Constant.U_NAME, binding.etNewName.getText().toString());
        user.put(Constant.U_SURNAME, binding.etNewSurname.getText().toString());
        user.put(Constant.U_DNI, binding.etNewDni.getText().toString());
        user.put(Constant.U_EMAIL, binding.etEmailNew.getText().toString());
        user.put(Constant.U_JOURNEY, journey);
        user.put(Constant.U_PHONE, binding.etPhoneNew.getText().toString());
        db.collection(Constant.NODO_USERS).document(editEmployee.getUid()).set(user, SetOptions.merge()).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                finish();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), getString(R.string.noDataSaved) + "\n" +e.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
    private void alertDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle(R.string.title_no_save);
        builder.setPositiveButton(R.string.acept, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.create().show();
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            alertDialog();
        }
        return super.onKeyDown(keyCode, event);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onResume() {
        super.onResume();
        Service.getInstance().loadLanguage(this);
    }

}