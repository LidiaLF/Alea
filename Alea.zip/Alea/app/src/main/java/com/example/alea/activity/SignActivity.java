package com.example.alea.activity;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.CompoundButton;

import com.example.alea.R;
import com.example.alea.databinding.ActivitySignBinding;
import com.example.alea.service.Service;
import com.example.alea.service.ServiceUser;
import com.example.alea.util.Constant;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import net.glxn.qrgen.android.QRCode;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SignActivity extends AppCompatActivity {
ActivitySignBinding binding;
 public String data, time;
 private static final String DASH = "-";
    boolean isStart, isBreak, isEnd, isWorking;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.swStart.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    binding.swEnd.setChecked(false);
                    binding.swStart.setEnabled(false);
                    binding.swBreak.setEnabled(true);
                    binding.swEnd.setEnabled(true);
                    doQR(Constant.SP_K_START);
                }else{
                    binding.swStart.setEnabled(true);
                    binding.swBreak.setEnabled(false);
                    binding.swEnd.setEnabled(false);
                }
            }
        });

        binding.swBreak.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    binding.swStart.setEnabled(false);
                    binding.swBreak.setEnabled(true);
                    binding.swEnd.setEnabled(false);
                    doQR(Constant.SP_K_BREAK1);
                }else{
                    binding.swStart.setEnabled(false);
                    binding.swBreak.setEnabled(true);
                    binding.swEnd.setEnabled(true);
                    doQR(Constant.SP_K_BREAK0);
                }
            }
        });

        binding.swEnd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    binding.swStart.setChecked(false);
                    binding.swStart.setEnabled(true);
                    binding.swBreak.setChecked(false);
                    binding.swBreak.setEnabled(false);
                    binding.swEnd.setEnabled(false);
                    doQR(Constant.SP_K_END);
                }else{
                    binding.swStart.setEnabled(false);
                    binding.swBreak.setEnabled(true);
                    binding.swEnd.setEnabled(true);
                }

            }
        });

    }


    public void doQR(String type){
        data = new SimpleDateFormat("MM/yyyy").format(new Date());
        time = new SimpleDateFormat("dd_HH:mm:ss").format(new Date());
        String mySign = Constant.CONTROL_CODE
                + ServiceUser.getInstance().getKeyCurrentUser(getApplicationContext())
                + DASH + data
                + DASH + type
                + DASH + time;
        Bitmap bitmap = QRCode.from(mySign).bitmap();
        binding.imageView.setImageBitmap(bitmap);

        Log.e("clave", mySign);
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onResume() {
        super.onResume();
        Service.getInstance().loadLanguage(this);
        isStart =  getSharedPreferences(Constant.SIGNS_SP, MODE_PRIVATE).getBoolean(Constant.SP_K_START, false);
        isBreak = getSharedPreferences(Constant.SIGNS_SP, MODE_PRIVATE).getBoolean(Constant.SP_K_BREAK, false);
        isEnd = getSharedPreferences(Constant.SIGNS_SP, MODE_PRIVATE).getBoolean(Constant.SP_K_END, false);

        if(isStart){
            if(isBreak){
                binding.swStart.setChecked(true);
                binding.swStart.setEnabled(false);
                binding.swBreak.setChecked(true);
                binding.swBreak.setEnabled(true);
                binding.swEnd.setChecked(false);
                binding.swEnd.setEnabled(false);
            }else{
                if(isEnd){
                    binding.swStart.setChecked(false);
                    binding.swStart.setEnabled(true);
                    binding.swBreak.setChecked(false);
                    binding.swBreak.setEnabled(false);
                    binding.swEnd.setChecked(true);
                    binding.swEnd.setEnabled(false);
                }else{
                    binding.swStart.setChecked(true);
                    binding.swStart.setEnabled(false);
                    binding.swBreak.setChecked(false);
                    binding.swBreak.setEnabled(true);
                    binding.swEnd.setChecked(false);
                    binding.swEnd.setEnabled(true);
                }
            }
        }else{
            binding.swStart.setChecked(false);
            binding.swStart.setEnabled(true);
            binding.swBreak.setChecked(false);
            binding.swBreak.setEnabled(false);
            binding.swEnd.setChecked(true);
            binding.swEnd.setEnabled(false);
        }
        binding.imageView.setImageResource(R.drawable.alea);
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor editor = getSharedPreferences(Constant.SIGNS_SP, MODE_PRIVATE).edit();
        editor.putBoolean(Constant.SP_K_START, binding.swStart.isChecked());
        editor.putBoolean(Constant.SP_K_BREAK, binding.swBreak.isChecked());
        editor.putBoolean(Constant.SP_K_END, binding.swEnd.isChecked());
        editor.commit();

        FirebaseFirestore.getInstance().collection(Constant.NODO_USERS)
                .document(ServiceUser.getInstance().getKeyCurrentUser(getApplicationContext())).get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot ds) {
                isWorking = (boolean) ds.get(Constant.U_ISWORKING);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e("onFailure get", e.getMessage());
            }
        });
        SharedPreferences.Editor eUser = getSharedPreferences(Constant.ALEA_SP, MODE_PRIVATE).edit();
        eUser.putBoolean(Constant.SP_ISWORKING, isWorking);
        eUser.commit();
    }
}