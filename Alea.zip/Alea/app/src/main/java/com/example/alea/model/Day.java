package com.example.alea.model;

import java.util.ArrayList;

public class Day {
    Saida s;

    public Day(Saida s) {
        this.s = s;
    }

    @Override
    public String toString() {
        return "Day{" +
                "s=" + s +
                '}';
    }
}
