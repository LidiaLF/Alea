package com.example.alea.fragment.group;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alea.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class GroupViewHolder extends RecyclerView.ViewHolder {
    TextView tvName, tvSurname;
    ImageView ivPicture, ivEmail, ivPhone;
    CircleImageView ivState;
    LinearLayout linearLayout;
    public GroupViewHolder(@NonNull View itemView) {
        super(itemView);
        linearLayout = itemView.findViewById(R.id.linear_users_Message);
        tvName = itemView.findViewById(R.id.tv_NameUser_Message);
        tvSurname = itemView.findViewById(R.id.tv_SurnameUser_Message);
        ivPicture = itemView.findViewById(R.id.iv_FotoMessage);
        //ivState = itemView.findViewById(R.id.iv_State);
        ivEmail = itemView.findViewById(R.id.iv_Email);
        ivPhone = itemView.findViewById(R.id.iv_phone);
    }

    public ImageView getIvEmail() {
        return ivEmail;
    }

    public void setIvEmail(ImageView ivEmail) {
        this.ivEmail = ivEmail;
    }

    public ImageView getIvPhone() {
        return ivPhone;
    }

    public void setIvPhone(ImageView ivPhone) {
        this.ivPhone = ivPhone;
    }

    public LinearLayout getLinearLayout() {
        return linearLayout;
    }

    public void setLinearLayout(LinearLayout linearLayout) {
        this.linearLayout = linearLayout;
    }

    public TextView getTvSurname() {
        return tvSurname;
    }

    public void setTvSurname(TextView tvSurname) {
        this.tvSurname = tvSurname;
    }

    public TextView getTvName() {
        return tvName;
    }

    public void setTvName(TextView tvName) {
        this.tvName = tvName;
    }

    public ImageView getIvPicture() {
        return ivPicture;
    }

    public void setIvPicture(ImageView ivPicture) {
        this.ivPicture = ivPicture;
    }

    public ImageView getIvState() {
        return ivState;
    }

    public void setIvState(CircleImageView ivState) {
        this.ivState = ivState;
    }
}