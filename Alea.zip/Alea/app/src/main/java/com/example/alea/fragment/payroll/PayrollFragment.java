package com.example.alea.fragment.payroll;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.alea.R;
import com.example.alea.databinding.FragmentPayrollBinding;
import com.example.alea.service.Service;
import com.example.alea.service.ServiceUser;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class PayrollFragment extends Fragment implements PayrollRecyclerAdapter.ListItemClickListener {

    private PayrollViewModel payrollViewModel;
    FragmentPayrollBinding binding;
    PayrollRecyclerAdapter adapter;
    ArrayList<String> payMonths, payMonthsUri;
    String uid;
    public static boolean download;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        payrollViewModel =
                ViewModelProviders.of(this).get(PayrollViewModel.class);
        View root = inflater.inflate(R.layout.fragment_payroll, container, false);
        binding = FragmentPayrollBinding.bind(root);
        final FloatingActionButton fab = getParentFragment().getActivity().findViewById(R.id.fab);
        fab.show();

        uid = ServiceUser.getInstance().getKeyCurrentUser(getContext());

        listPayrolls();

        return root;
    }

    private void listPayrolls() {
        //id para probas
        /**
         * Estructura para nominas
         * id.mes
         *
         */

       FirebaseStorage.getInstance().getReference().child(uid).child(getString(R.string.payrollFile)).list(6).addOnSuccessListener(new OnSuccessListener<ListResult>() {
           @Override
           public void onSuccess(ListResult listResult) {
               payMonths = new ArrayList<>();
               payMonthsUri = new ArrayList<>();
               String month;
               for(StorageReference sr : listResult.getItems()){
                   month = Service.getInstance().getMonth(sr.getName(), getContext());
                   payMonths.add(month);
                   payMonthsUri.add(sr.getName());

                   LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
                   binding.recyclerPayroll.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL));
                   binding.recyclerPayroll.setLayoutManager(layoutManager);
                   binding.recyclerPayroll.setHasFixedSize(true);
                   adapter = new PayrollRecyclerAdapter(payMonths, PayrollFragment.this);
                   binding.recyclerPayroll.setAdapter(adapter);
              }
           }
       });

    }

    @Override
    public void onListItemClick(int clickedItemIndex) {
        FirebaseStorage.getInstance().getReference().child(uid).child(getString(R.string.payrollFile)).child(payMonthsUri.get(clickedItemIndex)).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                if(download){
                    i.setType("application/pdf");
                    i.setData(uri);
                    i.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                }else{
                    i.setDataAndType(uri, "application/pdf");
                    i.addFlags( Intent.FLAG_ACTIVITY_NEW_TASK );
                }
                Intent intent = Intent.createChooser(i, getString(R.string.selectType));
                startActivity(intent);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(), getString(R.string.noPosible) + "\n" + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onResume() {
        super.onResume();
        Service.getInstance().loadLanguage(getContext());
    }
}