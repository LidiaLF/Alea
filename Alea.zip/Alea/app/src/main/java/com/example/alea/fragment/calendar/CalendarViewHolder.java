package com.example.alea.fragment.calendar;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alea.databinding.DesignRecyclerCalendarBinding;
import com.example.alea.model.Event;

import java.util.ArrayList;

public class CalendarViewHolder extends RecyclerView.Adapter<CalendarViewHolder.NumberViewHolder> {
        ArrayList<Event> events;

        final private CalendarViewHolder.ListItemClickListener mOnClickListener;
        public CalendarViewHolder(ArrayList<Event> events, CalendarViewHolder.ListItemClickListener listener){
                this.events = events;
                mOnClickListener = listener;
        }

        public interface ListItemClickListener{
                void onListItemClick(int clickedItemIndex);
        }

        @NonNull
        @Override
        public CalendarViewHolder.NumberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new CalendarViewHolder.NumberViewHolder(DesignRecyclerCalendarBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull CalendarViewHolder.NumberViewHolder holder, int position) {
                holder.bind(position);

        }

        @Override
        public int getItemCount() {
                return events.size();
        }



        class NumberViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener{
                DesignRecyclerCalendarBinding binding;
                NumberViewHolder(DesignRecyclerCalendarBinding b) {
                        super(b.getRoot());
                        binding = b;
                        b.getRoot().setOnClickListener(this);
                }

                //Enlaza os datos coa vista
                public void bind(int listIndex){
                        loadData(listIndex);
                }

                @Override
                public void onClick(View view) {
                        int clickedPosition = getAdapterPosition();
                        mOnClickListener.onListItemClick(clickedPosition);
                }

                @Override
                public boolean onLongClick(View v) {
                        return false;
                }


                /*
                 *
                 * Enche os campos do recycler view cos datos
                 * */
                private void loadData(int listIndex) {
                        binding.tvRnameEvent.setText(events.get(listIndex).getTitle());
                        binding.tvRtime.setText(events.get(listIndex).getTime());
                }
        }
}