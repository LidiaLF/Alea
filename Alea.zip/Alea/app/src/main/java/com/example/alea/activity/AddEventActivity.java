package com.example.alea.activity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.alea.R;
import com.example.alea.databinding.ActivityAddEventBinding;
import com.example.alea.service.Service;
import com.example.alea.service.ServiceUser;
import com.example.alea.util.Constant;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AddEventActivity extends AppCompatActivity {
    private static final String KEY_YEAR = "year";
    private static final String KEY_MONTH = "month";
    private static final String KEY_DAY = "day";
    private String PREFS_KEY = "switchPreferences";


    public static final int maxYears = 2050;
    public static final int minYears = 2019;

    String uid;
    int year, month, day;
    String time;
    boolean remember;
    ActivityAddEventBinding binding;
    Calendar mCalendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddEventBinding.inflate(getLayoutInflater());
        uid = ServiceUser.getInstance().getKeyCurrentUser(getApplicationContext());
        setContentView(binding.getRoot());

        mCalendar = Calendar.getInstance();
        year = (int) getIntent().getExtras().get(KEY_YEAR);
        month = (int) getIntent().getExtras().get(KEY_MONTH);
        day = (int) getIntent().getExtras().get(KEY_DAY);

        getCurrentDate();

        binding.switchRemember.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                Toast.makeText(getApplicationContext(), ""+ isChecked, Toast.LENGTH_LONG).show();
                remember = isChecked;
            }
        });

    }




    private void saveEvent() {
        if(binding.etNameEvent.getText() != null && !binding.etNameEvent.getText().toString().isEmpty()){
        //gardar en base de datos
            binding.relativeLayout.setVisibility(View.VISIBLE);
        String eid = day+""+month+""+year+""+binding.etSelectTime.getText().toString();
        Map<String, Object> event = new HashMap<>();
        event.put(Constant.C_DAY,day );
        event.put(Constant.C_MONTH, month+1);
        event.put(Constant.C_YEAR, year);
        event.put(Constant.C_TIME, binding.etSelectTime.getText().toString());
        event.put(Constant.C_TITLE, binding.etNameEvent.getText().toString());
        event.put(Constant.C_DESCRIPTION, binding.etDescEvent.getText().toString());
        event.put(Constant.C_REMEMBER, remember);
        FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).document(uid)
                .collection(Constant.NODO_CALENDAR).document(eid).set(event).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                binding.relativeLayout.setVisibility(View.GONE);
                finish();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                binding.relativeLayout.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), getString(R.string.evenNoSave) + "\n" + e.getMessage(), Toast.LENGTH_LONG).show();

            }
        });
        }else{
            Toast.makeText(getApplicationContext(), R.string.noTitle, Toast.LENGTH_LONG).show();
        }
    }
    private void getCurrentDate(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Date date = null;
        String myDate = year + "/" + (month+1) + "/" + day;
        try {
            date = sdf.parse(myDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        String sDate = DateFormat.getDateInstance(DateFormat.MEDIUM).format(cal.getTime());
        binding.etSelectDate.setText(sDate);
        String time = DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date().getTime());
        binding.etSelectTime.setText(time);
    }

    private void selectTime() {
        final Calendar calendar = Calendar.getInstance();
        TimePickerDialog timePickerDialog =
                new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
                        mCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        mCalendar.set(Calendar.MINUTE, minute);
                        time = DateFormat.getTimeInstance(DateFormat.SHORT).format(mCalendar.getTime());
                        binding.etSelectTime.setText(time);
                    }
                }, mCalendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true);
        timePickerDialog.show();
    }

    private void selectDate(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(AddEventActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int sYear, int monthOfYear, int dayOfMonth) {
                mCalendar.set(Calendar.YEAR, sYear);
                mCalendar.set(Calendar.MONTH, monthOfYear);
                mCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                 String date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(mCalendar.getTime());
                 binding.etSelectDate.setText(date);
                 year = sYear;
                 month = monthOfYear;
                 day = dayOfMonth;
            }
        }, year, month, day);
        datePickerDialog.show();
    }

    private void alertDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle(R.string.title_no_save);
        builder.setPositiveButton(R.string.acept, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.create().show();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            alertDialog();
        }
        return super.onKeyDown(keyCode, event);
    }

    public void onClick(View view) {
        switch (view.getId()){
            case R.id.iv_close:
                alertDialog();
                break;
            case R.id.iv_save:
                saveEvent();
                break;
            case R.id.et_select_date:
                selectDate();
                break;
            case R.id.et_select_time:
                selectTime();
                break;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onResume() {
        super.onResume();
        Service.getInstance().loadLanguage(this);
    }
}