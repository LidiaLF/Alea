package com.example.alea.adapter.message;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alea.R;
import com.example.alea.model.Message;

import java.util.ArrayList;

public class MessageAdapter extends RecyclerView.Adapter<MessageHolder> {

        private ArrayList<Message> listMessages = new ArrayList<>();
        private Context c;

        public MessageAdapter(Context c) {
            this.c = c;
        }

        public int addMessage(Message message){
            listMessages.add(message);

            int position = listMessages.size()-1;
            notifyItemInserted(listMessages.size());
            return position;
        }

        public void updateMessage(int position, Message message){
            listMessages.set(position,message);
            notifyItemChanged(position);
        }


    @NonNull
    @Override
    public MessageHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if(viewType==1){
            view = LayoutInflater.from(c).inflate(R.layout.card_view_menssage_e,parent,false);
        }else{
            view = LayoutInflater.from(c).inflate(R.layout.card_view_menssages_r,parent,false);
        }
        return new MessageHolder(view);
        }

    @Override
    public void onBindViewHolder(@NonNull MessageHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return listMessages.size();
    }
}
