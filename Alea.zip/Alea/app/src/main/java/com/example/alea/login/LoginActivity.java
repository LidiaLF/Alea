package com.example.alea.login;

import android.Manifest;
import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;
import android.widget.Toast;

import com.example.alea.R;
import com.example.alea.activity.AdminActivity;
import com.example.alea.activity.UserActivity;
import com.example.alea.databinding.ActivityLoginBinding;
import com.example.alea.service.Service;
import com.example.alea.service.ServiceUser;
import com.example.alea.util.Constant;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;

import java.util.HashMap;
import java.util.Map;


public class LoginActivity extends AppCompatActivity {
    private static final String KEY_ADMIN1 = "ADMIN1";
    private static final String KEY_ADMIN2 = "ADMIN2";
    private static final String KEY_ADMIN3 = "ADMIN3";
    private FirebaseAuth mAuth;
    private FirebaseRemoteConfig mFirebaseRemoteConfig;
    private LoginViewModel loginViewModel;
    ActivityLoginBinding binding;
    Intent i;
    private static final String USR_BD = "user";
    //PROBA PARA DESPLEGAR DISTINTOS LAYOUTS
    //(gardar estas variables en remoteConfig)
    private static  String ADMIN = "a@a.com";
    private static  String  A1 = "herminio@a.com";
    private static  String A2 = "manu@a.com";
    public static enum TIPOREDE{MOBIL,ETHERNET,WIFI,SENREDE};
    private TIPOREDE conexion;

    public static String storeLang;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        Service.getInstance().loadLanguage(this);
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(5)
                .build();
        mFirebaseRemoteConfig.setConfigSettingsAsync(configSettings);
        mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_config_defaults);
        mFirebaseRemoteConfig.fetchAndActivate() //Chamada ao servidor para recuperar os datos
                .addOnCompleteListener(new OnCompleteListener<Boolean>() {
                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
                    @Override
                    public void onComplete(@NonNull Task<Boolean> task) {
                        if(task.isSuccessful()){ //existe a configuracion  e recuperamos parametros
                            mFirebaseRemoteConfig.fetchAndActivate();
                            ADMIN = mFirebaseRemoteConfig.getString(KEY_ADMIN1);
                            A1 = mFirebaseRemoteConfig.getString(KEY_ADMIN2);
                            A2 = mFirebaseRemoteConfig.getString(KEY_ADMIN3);
                        }
                    }
                });



        loginViewModel = ViewModelProviders.of(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);

        mAuth = FirebaseAuth.getInstance();
        loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }
                //Se os datos son validos habilita o boton de aceptar
                binding.btLogin.setEnabled(loginFormState.isDataValid());
                if (loginFormState.getUsernameError() != null) {
                    binding.username.setError(getString(loginFormState.getUsernameError()));
                }
                if (loginFormState.getPasswordError() != null) {
                    binding.password.setError(getString(loginFormState.getPasswordError()));
                }
            }
        });

        loginViewModel.getLoginResult().observe(this, new Observer<LoginResult>() {
            @Override
            public void onChanged(@Nullable LoginResult loginResult) {
                if (loginResult == null) {
                    return;
                }
             //   binding.loading.setVisibility(View.GONE);
                if (loginResult.getError() != null) {
                    showLoginFailed(loginResult.getError());
                }
                if (loginResult.getSuccess() != null) {
                    checkUser();
                }
                setResult(Activity.RESULT_OK);
            }
        });


        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                loginViewModel.loginDataChanged(binding.username.getText().toString(),
                        binding.password.getText().toString());
            }
        };
        binding.username.addTextChangedListener(afterTextChangedListener);
        binding.password.addTextChangedListener(afterTextChangedListener);
        binding.password.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    loginViewModel.login(binding.username.getText().toString(),
                            binding.password.getText().toString());
                }
                return false;
            }
        });

        binding.btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                permisos();
                binding.rlLoading.setVisibility(View.VISIBLE);
            }
        });
    }


    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }

public void loginWithData(){
        loginViewModel.login(binding.username.getText().toString(),
                binding.password.getText().toString());
}
    /*
     * COMPROBAR QUE EXISTA O USUARIO E INICIO DO PERFIL
     * */
    public void checkUser(){
        mAuth.signInWithEmailAndPassword(binding.username.getText().toString(), binding.password.getText().toString())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            saveCurrentUser();


                        } else {
                            conexion = checkNet();
                            if (conexion == TIPOREDE.SENREDE) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                                builder.setCancelable(false);
                                builder.setIcon(android.R.drawable.ic_dialog_alert);
                                builder.setTitle(R.string.noNet);
                                builder.setMessage(getString(R.string.noConection) + "\n" + getString(R.string.reducedFunctions));
                                builder.setPositiveButton(R.string.acept, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        String myUser = ServiceUser.getInstance().getCurrentUser(LoginActivity.this);
                                        String myPwd = ServiceUser.getInstance().getPwdCurrentUser(LoginActivity.this);
                                        if(myUser.equalsIgnoreCase(binding.username.getText().toString())){
                                            if(myPwd.equals(binding.password.getText().toString())){
                                                initUser(myUser);
                                            }else {
                                                binding.password.setError(getString(R.string.failPwd));
                                            }
                                        }else{
                                            binding.username.setError(getString(R.string.failUser));
                                        }
                                    }
                                });
                                builder.create().show();
                            }else{
                            Toast.makeText(LoginActivity.this, R.string.login_no_exist, Toast.LENGTH_LONG).show();
                                  updateUI(null);
                            }
                        }
                    }
                });

    }



    /*
    *
    * INICIO DO LAYOUT CORRESPONDENTE PARA CADA USUARIO
    * */
    private void initUser(String email) {
     //  String email =  mAuth.getCurrentUser().getEmail();
        if(email.equalsIgnoreCase(ADMIN)|| email.equalsIgnoreCase(A1)|| email.equalsIgnoreCase(A2)){
            i = new Intent(LoginActivity.this, AdminActivity.class);
            startActivity(i);
            binding.rlLoading.setVisibility(View.GONE);
        }else{
            i = new Intent(LoginActivity.this, UserActivity.class);
            i.putExtra(USR_BD, binding.username.getText().toString());
            startActivity(i);
            binding.rlLoading.setVisibility(View.GONE);
        }
    }

    /*
     *  PREFERENCIAS PARA MANTER O USUARIO CON SESION INICIADA
     * */
    public void updateUI(FirebaseUser currentUser){
        if(currentUser != null){
          initUser(ServiceUser.getInstance().getCurrentUser(LoginActivity.this));
        }
    }

    private void saveCurrentUser() {
        if(!mAuth.getUid().equals(ServiceUser.getInstance().getKeyCurrentUser(this))){
            SharedPreferences sp = getSharedPreferences( Constant.SIGNS_SP, Context.MODE_PRIVATE);
            SharedPreferences.Editor e = sp.edit();
            e.putBoolean(Constant.SP_K_START, false);
            e.putBoolean(Constant.SP_K_BREAK, false);
            e.putBoolean(Constant.SP_K_END, false);
        }
        FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).document(mAuth.getUid()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot ds) {
                SharedPreferences sharedPref = getSharedPreferences( Constant.ALEA_SP, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString(Constant.SP_USER, binding.username.getText().toString());
                editor.putString(Constant.SP_PWD, binding.password.getText().toString());
                editor.putString(Constant.SP_UID, mAuth.getUid());
                editor.putString(Constant.SP_NAME, ds.getString(Constant.U_NAME));
                editor.putString(Constant.SP_SURNAME, ds.getString(Constant.U_SURNAME));
                editor.commit();

                Map<String, Object> data = new HashMap<>();
                data.put(Constant.U_PWD, binding.password.getText().toString());
                data.put(Constant.U_UID, mAuth.getUid());
                FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).document(mAuth.getUid()).set(data, SetOptions.merge()).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        initUser(mAuth.getCurrentUser().getEmail());
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(!binding.chbxRemind.isChecked())
            mAuth.signOut();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onResume() {
        super.onResume();
        Service.getInstance().loadLanguage(this);
    }

    public void permisos(){
        if (Build.VERSION.SDK_INT>=23){
            int permiso1 = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            int permiso2 = checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
            int permiso3 = checkSelfPermission(Manifest.permission.VIBRATE);
            int permiso4 = checkSelfPermission(Manifest.permission.INTERNET);
            if (permiso1 == PackageManager.PERMISSION_GRANTED &
                    permiso2 == PackageManager.PERMISSION_GRANTED &
                    permiso3 == PackageManager.PERMISSION_GRANTED &
                    permiso4 == PackageManager.PERMISSION_GRANTED){
                loginWithData();
            }
            else{
                this.requestPermissions( new String[]{ Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE,  Manifest.permission.VIBRATE,
                        Manifest.permission.INTERNET}, 1);
            }

        }else {
            loginWithData();
        }

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loginWithData();

            } else {
                Toast.makeText(this, R.string.needPermission, Toast.LENGTH_LONG).show();
            }
        }

    }

    private TIPOREDE checkNet(){
        NetworkInfo networkInfo=null;

        ConnectivityManager connMgr = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()) {
            switch(networkInfo.getType()){
                case ConnectivityManager.TYPE_MOBILE:
                    return TIPOREDE.MOBIL;
                case ConnectivityManager.TYPE_ETHERNET:
                    return TIPOREDE.ETHERNET;
                case ConnectivityManager.TYPE_WIFI:
                    return TIPOREDE.WIFI;
            }
        }
        return TIPOREDE.SENREDE;
    }
}