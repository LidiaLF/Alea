package com.example.alea.model;

import java.io.Serializable;

public class Employee implements Serializable {
    String uid,name, surname, email, phone, pwd, dni;
    double hoursContract, hoursWorked;

    public Employee() {
    }

    public Employee(String uid ,String name, String surname,String dni, String email, String phone, double hoursContract) {
        this.uid = uid;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.phone = phone;
        this.hoursContract = hoursContract;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public double getHoursContract() {
        return hoursContract;
    }

    public void setHoursContract(double hoursContract) {
        this.hoursContract = hoursContract;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id='" + uid + '\'' +
                ", name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", pwd='" + pwd + '\'' +
                ", dni='" + dni + '\'' +
                ", hoursContract=" + hoursContract +
                ", hoursWorked=" + hoursWorked +
                '}';
    }
}

