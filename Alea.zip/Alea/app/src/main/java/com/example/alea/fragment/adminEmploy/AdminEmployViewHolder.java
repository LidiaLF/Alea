package com.example.alea.fragment.adminEmploy;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alea.R;

public class AdminEmployViewHolder extends RecyclerView.ViewHolder {
    TextView tvName, tvSurname;
    ImageView ivSetting, ivDownHours;
    LinearLayout linearLayout;
    public AdminEmployViewHolder(@NonNull View itemView) {
        super(itemView);
        linearLayout = itemView.findViewById(R.id.linear_users);
        tvName = itemView.findViewById(R.id.tv_listUserName);
        tvSurname = itemView.findViewById(R.id.tv_listUserSurname);
        ivSetting = itemView.findViewById(R.id.iv_setting);
        ivDownHours = itemView.findViewById(R.id.iv_downHours);

    }

    public TextView getTvName() {
        return tvName;
    }

    public void setTvName(TextView tvName) {
        this.tvName = tvName;
    }

    public ImageView getIvSetting() {
        return ivSetting;
    }

    public void setIvSetting(ImageView ivSetting) {
        this.ivSetting = ivSetting;
    }

    public ImageView getIvDownHours() {
        return ivDownHours;
    }

    public void setIvDownHours(ImageView ivDownHours) {
        this.ivDownHours = ivDownHours;
    }

    public LinearLayout getLinearLayout() {
        return linearLayout;
    }

    public void setLinearLayout(LinearLayout linearLayout) {
        this.linearLayout = linearLayout;
    }

    public TextView getTvSurname() {
        return tvSurname;
    }

    public void setTvSurname(TextView tvSurname) {
        this.tvSurname = tvSurname;
    }

    public TextView getTv() {
        return tvName;
    }

    public void setTv(TextView tv) {
        this.tvName = tv;
    }
}