package com.example.alea.fragment.adminEmploy;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Environment;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.alea.R;
import com.example.alea.activity.NewEmployActivity;
import com.example.alea.databinding.FragmentAdminEmployBinding;
import com.example.alea.model.Employee;
import com.example.alea.model.Month;
import com.example.alea.service.Service;
import com.example.alea.util.Constant;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.UploadTask;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;

public class AdminEmployFragment extends Fragment {
    Intent i;
    FragmentAdminEmployBinding binding;
    FirestoreRecyclerAdapter adapter;
    Query query;
    String uid;
    String nombreArchivo;
    String rutaArchivo;
    File file, fileExcel;
    FileOutputStream fileOuS;
    Month m;
    Snackbar snackbar;
    private static final String USR_EDIT = "user_edit";
    private static final String ACTION = "action";
    private static final int CODE_SELECT_PAY = 12;
    public static AdminEmployFragment newInstance() {
        return new AdminEmployFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        View root = inflater.inflate(R.layout.fragment_admin_employ, container, false);
        binding = FragmentAdminEmployBinding.bind(root);

        //Deshabilitar botón flotante fichaxes
        final FloatingActionButton fab = getParentFragment().getActivity().findViewById(R.id.fab);
        fab.hide();

        //Botón flotante para engadir empregado novo
        binding.addEmploy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i = new Intent(getActivity(), NewEmployActivity.class);
                i.putExtra(ACTION, getString(R.string.newEmploy));
                startActivity(i);
            }
        });

        //Botón flotante para subir as nóminas
        binding.addPayroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setIcon(android.R.drawable.ic_dialog_info);
                builder.setTitle(R.string.remember);
                builder.setMessage(getString(R.string.info_payrolls)+ "\n\t\t" +getString(R.string.idEmploy)+"." + "pdf");
                builder.setPositiveButton(R.string.acept, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        try {
                            Intent intent = new Intent();
                            intent.setType("application/pdf");
                            intent.addCategory(Intent.CATEGORY_OPENABLE);
                            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                            intent.setAction(Intent.ACTION_GET_CONTENT);
                            startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"), CODE_SELECT_PAY);
                        }catch(Exception e){
                            Toast.makeText(getContext(), R.string.installFileManager,
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                builder.create().show();
                    }
                });

        listEmployees();

        return root;
    }

    private void listEmployees() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        binding.recyclerUsers.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL));
        binding.recyclerUsers.setLayoutManager(layoutManager);
        query = FirebaseFirestore.getInstance()
                .collection(Constant.NODO_USERS);


        final FirestoreRecyclerOptions<Employee> options =  new  FirestoreRecyclerOptions.Builder < Employee > ()
                .setQuery (query,Employee.class)
                .build();

        adapter = new FirestoreRecyclerAdapter<Employee, AdminEmployViewHolder>(options) {
            @Override
            public void onBindViewHolder(AdminEmployViewHolder holder, final int position, final Employee model) {
                holder.getTv().setText(model.getName());
                holder.getTvSurname().setText(model.getSurname());

                /*
                * Edita un usuario ante un Click
                * */
                holder.getIvSetting().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).get()
                                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                            @Override
                            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                DocumentSnapshot ds = queryDocumentSnapshots.getDocuments().get(position);
                                Employee employee =  new Employee(ds.getId() ,
                                        ds.getString(Constant.U_NAME), ds.getString(Constant.U_SURNAME), ds.getString(Constant.U_DNI),
                                        ds.getString(Constant.U_EMAIL), ds.getString(Constant.U_PHONE), ds.getDouble(Constant.U_JOURNEY));
                                employee.setDni(ds.getString(Constant.U_DNI));
                                i = new Intent(getActivity(), NewEmployActivity.class);
                                Bundle b = new Bundle();
                                b.putSerializable(USR_EDIT, employee);
                                i.putExtras(b);
                                i.putExtra(ACTION, getString(R.string.editEmploy));
                                startActivity(i);
                            }
                                });
                    }
                });

                holder.getIvDownHours().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ArrayList<Integer> years = new ArrayList<>();
                        years.add(Calendar.getInstance().get(Calendar.YEAR));
                        years.add(Calendar.getInstance().get(Calendar.YEAR)-1);
                        years.add(Calendar.getInstance().get(Calendar.YEAR)-2);
                        years.add(Calendar.getInstance().get(Calendar.YEAR)-3);

                        final Spinner spMonth = new Spinner(getContext());
                       ArrayAdapter adpM = ArrayAdapter.createFromResource(getContext(), R.array.months,
                                android.R.layout.simple_spinner_item);

                        final Spinner spYear = new Spinner(getContext());
                        ArrayAdapter adpY =  new ArrayAdapter(getContext(),
                                android.R.layout.simple_spinner_item,
                                years);


                        LinearLayout linearLayout = new LinearLayout(getContext());
                        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        layoutParams.setMargins(50, 20, 20, 20);

                        spMonth.setLayoutParams(layoutParams);
                        spMonth.setAdapter(adpM);

                        spYear.setLayoutParams(layoutParams);
                        spYear.setAdapter(adpY);
                        spYear.setSelection(0);

                        linearLayout.addView(spMonth);
                        linearLayout.addView(spYear);

                        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                        builder.setTitle(R.string.selectDate);
                        builder.setMessage("\n\t" + model.getName());
                        builder.setView(linearLayout);
                        builder.setPositiveButton(R.string.acept, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                int month = spMonth.getSelectedItemPosition();
                                String year = spYear.getSelectedItem().toString();
                                downloadSigns(model.getName(),  model.getSurname(), model.getDni(), model.getUid(), month, year);

                            }
                        }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                        builder.setCancelable(false);
                        builder.create().show();
                    }
                });
                /*
                * Borra usuario ante un LongClick
                * */
                holder.getLinearLayout().setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        alertRemove(options, position);
                        return false;
                    }
                });
            }

            @Override
            public AdminEmployViewHolder onCreateViewHolder(ViewGroup group, int i) {
                View view = LayoutInflater.from(group.getContext())
                        .inflate(R.layout.design_recycler_users, group, false);

                return new AdminEmployViewHolder(view);
            }
        };
        binding.recyclerUsers.setAdapter(adapter);

    }

    private void downloadSigns(final String name, final String surname, final String dni, final String id, final int  month, final String year) {
        if(month==0){
            FirebaseFirestore.getInstance().collection(Constant.NODO_SIGNS).document(id).collection(year).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
          @RequiresApi(api = Build.VERSION_CODES.KITKAT)
          @Override
          public void onSuccess(QuerySnapshot documentSnapshot) {
             if(documentSnapshot == null | documentSnapshot.isEmpty()){
                  Toast.makeText(getContext(), R.string.noSignsYear, Toast.LENGTH_LONG).show();
              }else {


                  nombreArchivo = "_" + year + ".xlsx";
                  rutaArchivo = Environment.getExternalStorageDirectory() + Constant.URL_SIGNS + name;

                  Workbook wb = new HSSFWorkbook();
                  for(DocumentSnapshot ds : documentSnapshot.getDocuments()){
                      printExcel(wb, ds, name, surname, dni , month, year);
              }

                  file = new File(rutaArchivo);
                  file.mkdirs();
                  try {
                      fileExcel =  new File(file, nombreArchivo);
                      fileOuS = new FileOutputStream(fileExcel);
                      if (file.exists()) {
                          file.delete();
                      }
                      wb.write(fileOuS);
                      fileOuS.flush();
                      fileOuS.close();
                      snackbar = Snackbar.make(binding.getRoot(), getString(R.string.excelCreated)+ " " + file.getAbsolutePath(), BaseTransientBottomBar.LENGTH_LONG);
                      snackbar.setAction(R.string.open, new GoToListener());
                      snackbar.show();

                  } catch (FileNotFoundException e) {
                      e.printStackTrace();
                  } catch (IOException e) {
                      e.printStackTrace();
                  }
              }
          }
      }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }else{
                   FirebaseFirestore.getInstance().collection(Constant.NODO_SIGNS).document(id).collection(year).document(String.valueOf(month)).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                @Override
                public void onSuccess(DocumentSnapshot ds) {
                    if(ds.getData() == null || ds.getData().isEmpty()){
                        Toast.makeText(getContext(), R.string.noSignsMonth, Toast.LENGTH_LONG).show();

                    }else{
                        Workbook wb = new HSSFWorkbook();
                        nombreArchivo= month + "_" + year + ".xls";
                        rutaArchivo=  Environment.getExternalStorageDirectory() + Constant.URL_SIGNS + name;
                        printExcel(wb, ds, name, surname, dni , month, year);

                        file = new File(rutaArchivo);
                        file.mkdirs();
                        try {
                            fileOuS = new FileOutputStream(new File(file, nombreArchivo));
                            if (file.exists()) {
                                file.delete();
                            }
                            wb.write(fileOuS);
                            fileOuS.flush();
                            fileOuS.close();
                            snackbar = Snackbar.make(binding.getRoot(),getString(R.string.excelCreated)+ " " + file.getAbsolutePath() , BaseTransientBottomBar.LENGTH_LONG);
                            snackbar.setAction(R.string.open, new GoToListener());
                            snackbar.show();
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });

        }
    }



    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void printExcel(Workbook wb, DocumentSnapshot ds, String name, String surname, String dni, int month, String year){
        Cell cell = null;
        CellStyle dataEmployee = wb.createCellStyle();
        dataEmployee.setFillForegroundColor(HSSFColor.LIGHT_GREEN.index);
        dataEmployee.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        Font font1 = wb.createFont();
        font1.setBold(true);
        dataEmployee.setFont(font1);

        CellStyle cellStyle = wb.createCellStyle();
        cellStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        Font font = wb.createFont();
        font.setBold(true);
        cellStyle.setFont(font);

        Sheet sheet = null;
        sheet = wb.createSheet(ds.getId()+"");

        Row row = null;
        row = sheet.createRow(0);
        cell = row.createCell(0);
        cell.setCellValue(surname + ", " + name);
        cell.setCellStyle(dataEmployee);

        sheet.createRow(1);
        cell = row.createCell(1);
        cell.setCellValue(dni);
        cell.setCellStyle(dataEmployee);

        sheet.createRow(2);
        cell = row.createCell(2);
        cell.setCellValue(Service.getInstance().getMonth(String.valueOf(month), getContext()) + " " + year);
        cell.setCellStyle(dataEmployee);

        row = sheet.createRow(1);
        cell = row.createCell(0);
        cell.setCellValue("");
        cell.setCellStyle(cellStyle);

        sheet.createRow(1);
        cell = row.createCell(1);
        cell.setCellValue(getString(R.string.day));
        cell.setCellStyle(cellStyle);

        sheet.createRow(2);
        cell = row.createCell(2);
        cell.setCellValue(getString(R.string.entry));
        cell.setCellStyle(cellStyle);

        sheet.createRow(3);
        cell = row.createCell(3);
        cell.setCellValue(getString(R.string.breakI));
        cell.setCellStyle(cellStyle);

        sheet.createRow(4);
        cell = row.createCell(4);
        cell.setCellValue(getString(R.string.breakF));
        cell.setCellStyle(cellStyle);

        sheet.createRow(5);
        cell = row.createCell(5);
        cell.setCellValue(getString(R.string.out));
        cell.setCellStyle(cellStyle);

        String diaSub = "";
        int i = 2;

        Map<String, Object> treeMap = new TreeMap<String, Object>(ds.getData());
        for (Map.Entry<String, Object> entry : treeMap.entrySet()) {
            String[] parts = entry.getKey().split("_");

            if(!parts[0].equalsIgnoreCase(diaSub)){
                row = sheet.createRow(i);
                cell = row.createCell(1);
                cell.setCellValue(parts[0]);
                diaSub = parts[0];
                i++;
            }

            if(entry.getValue().equals("E")){
                if(cell.getCellType() != Cell.CELL_TYPE_BLANK){
                    row = sheet.createRow(i);
                    cell = row.createCell(2);
                    cell.setCellValue(parts[1]);
                    i++;
               }else{
                    cell = row.createCell(2);
                    cell.setCellValue(parts[1]);
                }
            }
            if(entry.getValue().equals("D1")){
                cell = row.createCell(3);
                cell.setCellValue(parts[1]);
            }
            if(entry.getValue().equals("D0")){
                cell = row.createCell(4);
                cell.setCellValue(parts[1]);
            }
            if(entry.getValue().equals("S")){
                cell = row.createCell(5);
                cell.setCellValue(parts[1]);
            }
        }


    }


    private void alertRemove(final FirestoreRecyclerOptions<Employee> options, final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setCancelable(false);
        builder.setTitle(R.string.alertDeleteUser);
        builder.setMessage(getString(R.string.message_deleteUser) + "\n\t\t" +
                options.getSnapshots().get(position).getName() + " " +
                options.getSnapshots().get(position).getSurname() + "?");
        builder.setIcon(R.drawable.ic_alert_triangle);
        builder.setPositiveButton(R.string.guess, new
                DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                       removeDataUser(options, position);
                        //Toast.makeText(getContext(), R.string.user_remove, Toast.LENGTH_LONG).show();
                    }
                });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.create().show();
    }



       private void removeDataUser(FirestoreRecyclerOptions<Employee> options, final int position) {

        FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
              uid = queryDocumentSnapshots.getDocuments().get(position).getId();
                FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).document(uid)
                        .delete()
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                adapter.notifyDataSetChanged();
                                Log.e("removeData", "DocumentSnapshot successfully deleted!");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getContext(), getString(R.string.noDelete) + "\n" + e.getMessage() , Toast.LENGTH_LONG).show();
                                Log.e("removeData", "Error deleting document", e);
                            }
                        });
            }
        });


    }
/*
* PROBA CON SELECT CHOOSER MULTIPLE
*  Estructura nomenclatura de nominas uid.pdf
**/
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        binding.rlLoadPay.setVisibility(View.VISIBLE);
        String month = String.valueOf(Calendar.getInstance().getTime().getMonth());
        String path;
        switch (requestCode){
            case CODE_SELECT_PAY:
                if(data.getClipData() == null){
                    path = data.getData().getLastPathSegment().substring(data.getData().getLastPathSegment().lastIndexOf('/')+1,
                            data.getData().getLastPathSegment().lastIndexOf('.'));
                    FirebaseStorage.getInstance().getReference().child(path).child(getString(R.string.payrollFile))
                            .child(month).putFile(data.getData()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            binding.rlLoadPay.setVisibility(View.GONE);
                        }
                    });
                }else{
                    for(int i = 0; i <  data.getClipData().getItemCount(); i++ ){
                        path = data.getClipData().getItemAt(i).getUri().getLastPathSegment()
                                .substring(data.getClipData().getItemAt(i).getUri().getLastPathSegment().lastIndexOf('/')+1,
                                        data.getClipData().getItemAt(i).getUri().getLastPathSegment().lastIndexOf('.'));
                        FirebaseStorage.getInstance().getReference().child(path)
                                .child(getString(R.string.payrollFile))
                                .child(month).putFile(data.getClipData().getItemAt(i).getUri()).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                binding.rlLoadPay.setVisibility(View.GONE);
                            }
                        });
                }
                }
                break;
        }
    }

    public class GoToListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            try{    Log.e("FOS", file.getPath().toString() + "");
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(Uri.fromFile(fileExcel), "application/vnd.ms-excel");
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            startActivity(intent);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(getContext(),R.string.noAppExcel, Toast.LENGTH_SHORT).show();
        }
        }
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // TODO: Use the ViewModel
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onResume() {
        super.onResume();
        Service.getInstance().loadLanguage(getContext());
    }
    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

}