package com.example.alea.fragment.group;

import androidx.annotation.RequiresApi;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.alea.R;
import com.example.alea.activity.MessageActivity;
import com.example.alea.adapter.GlideApp;
import com.example.alea.databinding.FragmentGroupBinding;
import com.example.alea.model.Employee;
import com.example.alea.service.Service;
import com.example.alea.service.ServiceUser;
import com.example.alea.util.Constant;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class GroupAleaFragment extends Fragment {
    private FirestoreRecyclerAdapter adapterWorking, adapterNotWorking;
    FragmentGroupBinding binding;
    String uid;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_group, container, false);
        binding =  FragmentGroupBinding.bind(root);
        final FloatingActionButton fab = getParentFragment().getActivity().findViewById(R.id.fab);
        fab.show();

        uid = ServiceUser.getInstance().getKeyCurrentUser(getContext());
        Log.e("uid group", uid + "");
        listEmployees();
        return root;
    }

    public void listEmployees(){
        LinearLayoutManager layoutManagerConnected = new LinearLayoutManager(getContext());
      //  LinearLayoutManager layoutManagerDisconnected = new LinearLayoutManager(getContext());
        binding.recyclerConnected.setLayoutManager(layoutManagerConnected);

        Query queryWorking = FirebaseFirestore.getInstance()
                .collection(Constant.NODO_USERS).whereNotEqualTo(Constant.U_UID, uid);

        final FirestoreRecyclerOptions<Employee> optionsWorking =  new  FirestoreRecyclerOptions.Builder <Employee> ()
                .setQuery (queryWorking,Employee.class)
                .build();
        adapterWorking = new FirestoreRecyclerAdapter<Employee, GroupViewHolder>(optionsWorking) {
            @Override
            protected void onBindViewHolder(@NonNull GroupViewHolder holder, final int position, @NonNull final Employee employee) {
                final String id = getSnapshots().getSnapshot(position).getId();
                ServiceUser.getInstance().loadImage(id, getContext(), holder.getIvPicture());
                holder.getTvName().setText(employee.getName());
                holder.getTvSurname().setText(employee.getSurname());
//                holder.getIvState().setImageResource(R.color.green);
                holder.getIvPhone().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        callPhone(employee.getPhone());
                    }
                });

                holder.getIvEmail().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        sendEmail(employee.getEmail());
                    }
                });
            }

            @Override
            public GroupViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.design_recycler_group, parent, false);
                return new GroupViewHolder(view);
            }
        };
      /*  binding.recyclerDisconnected.setLayoutManager(layoutManagerDisconnected);
        Query queryWorking = FirebaseFirestore.getInstance()
                .collection(Constant.NODO_USERS).whereNotEqualTo(Constant.U_UID, uid).whereEqualTo(Constant.U_ISWORKING, true);
        Query queryNotWorking = FirebaseFirestore.getInstance()
                .collection(Constant.NODO_USERS).whereNotEqualTo(Constant.U_UID, uid).whereEqualTo(Constant.U_ISWORKING, false);


        final FirestoreRecyclerOptions<Employee> optionsWorking =  new  FirestoreRecyclerOptions.Builder <Employee> ()
                .setQuery (queryWorking,Employee.class)
                .build();

        final FirestoreRecyclerOptions<Employee> optionsNotWorking =  new  FirestoreRecyclerOptions.Builder <Employee> ()
                .setQuery (queryNotWorking,Employee.class)
                .build();

        adapterWorking = new FirestoreRecyclerAdapter<Employee, GroupViewHolder>(optionsWorking) {
            @Override
            protected void onBindViewHolder(@NonNull GroupViewHolder holder, final int position, @NonNull final Employee employee) {
                final String id = getSnapshots().getSnapshot(position).getId();
                ServiceUser.getInstance().loadImage(id, getContext(), holder.getIvPicture());
                holder.getTvName().setText(employee.getName());
                holder.getTvSurname().setText(employee.getSurname());
//                holder.getIvState().setImageResource(R.color.green);

                holder.getLinearLayout().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                       Intent intent = new Intent(getActivity(), MessageActivity.class);
                        intent.putExtra(Constant.KEY_ID,id);
                        intent.putExtra(Constant.KEY_NAME, employee.getName());
                        intent.putExtra(Constant.KEY_TLF, employee.getPhone());
                        intent.putExtra(Constant.KEY_EMAIL, employee.getEmail());
                        startActivity(intent);
                    }
                });
            }

            @Override
            public GroupViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.design_recycler_group, parent, false);
                return new GroupViewHolder(view);
            }
        };

        adapterNotWorking = new FirestoreRecyclerAdapter<Employee, GroupViewHolder>(optionsNotWorking) {
            @NonNull
            @Override
            public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.design_recycler_group, parent, false);
                return new GroupViewHolder(view);
            }

            @Override
            protected void onBindViewHolder(@NonNull GroupViewHolder holder, int position, @NonNull Employee employee) {
                final String id = getSnapshots().getSnapshot(position).getId();
                ServiceUser.getInstance().loadImage(id, getContext(), holder.getIvPicture());
                holder.getTvName().setText(employee.getName());
                holder.getTvSurname().setText(employee.getSurname());
            }
        };

        binding.recyclerConnected.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.HORIZONTAL));
        binding.recyclerDisconnected.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.HORIZONTAL));

        binding.recyclerConnected.setAdapter(adapterWorking);
        binding.recyclerDisconnected.setAdapter(adapterNotWorking);*/
        binding.recyclerConnected.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.HORIZONTAL));
        binding.recyclerConnected.setAdapter(adapterWorking);


    }

    public void sendEmail(String email){
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
        startActivity(intent);

    }


    public void callPhone(String phone){
        Intent i = new Intent(Intent.ACTION_DIAL);
        i.setData(Uri.parse("tel:" + phone));
        startActivity(i);
    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onResume() {
        super.onResume();
        Service.getInstance().loadLanguage(getContext());
       // adapterNotWorking.notifyDataSetChanged();
        adapterWorking.notifyDataSetChanged();
    }

    @Override
    public void onStart() {
        super.onStart();
        adapterWorking.startListening();
//        adapterNotWorking.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapterWorking.stopListening();
      //  adapterNotWorking.stopListening();
    }
}








