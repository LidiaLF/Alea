package com.example.alea.fragment.home;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.alea.R;
import com.example.alea.adapter.GlideApp;
import com.example.alea.databinding.FragmentHomeBinding;
import com.example.alea.fragment.calendar.CalendarViewHolder;
import com.example.alea.model.Event;
import com.example.alea.service.Service;
import com.example.alea.service.ServiceUser;
import com.example.alea.util.Constant;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    FragmentHomeBinding binding;
    String uid;
    ArrayList<Event> events;
    public String data, time;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        events = new ArrayList<>();
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        binding = FragmentHomeBinding.bind(root);

        final FloatingActionButton fab = getParentFragment().getActivity().findViewById(R.id.fab);
        fab.show();

        ServiceUser.getInstance().loadImage(uid, getContext(), binding.ivImageRound);
        binding.tvName.setText(ServiceUser.getInstance().getNameCurrentUser(getContext()) + " " +
                ServiceUser.getInstance().getSurnameCurrentUser(getContext()));
        listEvent();
        return binding.getRoot();
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void listEvent() {
        Log.e("onSucess", "listEvet");
        events.clear();
        time = new SimpleDateFormat("HH").format(new Date());
        data = new SimpleDateFormat("mm").format(new Date());
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        binding.recycler.addItemDecoration(new DividerItemDecoration(Objects.requireNonNull(getContext()), DividerItemDecoration.VERTICAL));
        binding.recycler.setLayoutManager(layoutManager);

        FirebaseFirestore.getInstance().collection(Constant.NODO_USERS).document(uid)
                .collection(Constant.NODO_CALENDAR)
                .whereEqualTo(Constant.C_YEAR, Calendar.getInstance().get(Calendar.YEAR) )
                .whereEqualTo(Constant.C_MONTH, Calendar.getInstance().get(Calendar.MONTH)+1)
                .whereEqualTo(Constant.C_DAY, Calendar.getInstance().get(Calendar.DAY_OF_MONTH))
                .whereEqualTo(Constant.C_REMEMBER, true)
                .get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {

            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                for(DocumentSnapshot d : queryDocumentSnapshots.getDocuments()){
                    String[] times =  d.get(Constant.C_TIME).toString().split(":");
                    boolean add = false;
                   if(Integer.parseInt(time) < Integer.parseInt(times[0])){
                       add = true;
                   }else if(Integer.parseInt(time) == Integer.parseInt(times[0])) {
                       if (Integer.parseInt(data) <= Integer.parseInt(times[1])) {
                           add = true;
                       }
                   }
                   if (add){
                       events.add(new Event(
                               d.getId(),
                               Integer.parseInt(d.get(Constant.C_DAY).toString()),
                               Integer.parseInt(d.get(Constant.C_MONTH).toString()),
                               Integer.parseInt(d.get(Constant.C_YEAR).toString()),
                               d.get(Constant.C_TIME).toString(),
                               d.get(Constant.C_TITLE).toString(),
                               d.get(Constant.C_DESCRIPTION).toString(),
                               Boolean.parseBoolean(d.get(Constant.C_REMEMBER).toString())));
                   }
                }
               CalendarViewHolder adapter = new CalendarViewHolder(events, new CalendarViewHolder.ListItemClickListener() {
                    @Override
                    public void onListItemClick(int itemClick) {
                        //showEvent(itemClick);
                    }
                });
                binding.recycler.setAdapter(adapter);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(), R.string.noPosible + "\n" + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onResume() {
        super.onResume();
        //listEvent();
        ServiceUser.getInstance().loadImage(uid, getContext(), binding.ivImageRound);
        binding.tvName.setText(ServiceUser.getInstance().getNameCurrentUser(getContext()) + " " +
                ServiceUser.getInstance().getSurnameCurrentUser(getContext()));
        Service.getInstance().loadLanguage(getContext());
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        uid = ServiceUser.getInstance().getKeyCurrentUser(getContext());
        Log.e("uid", uid+ "");

    }
}