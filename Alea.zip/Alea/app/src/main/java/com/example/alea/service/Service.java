package com.example.alea.service;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.preference.PreferenceManager;

import androidx.annotation.RequiresApi;

import com.example.alea.R;

import java.util.Locale;

public class Service {
    private static Service mInstance = null;
    String language;
    public Service(){}

    public static synchronized Service getInstance() {
        if (mInstance == null) {
            mInstance = new Service();
        }

        return mInstance;
    }


    /*
    * SERVICIOS DE IDIOMA
    * */
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void loadLanguage(Context context) {
        SharedPreferences shp = PreferenceManager.getDefaultSharedPreferences(context);
        language = shp.getString("keyLanguage", "gl");

        Configuration config = new Configuration();
        config.locale = Locale.forLanguageTag(language);
        context.getResources().updateConfiguration(
                config,
                context.getResources().getDisplayMetrics()
        );
    }

    public String getLanguage() {
        return language;
    }



    /*
    * SERVICIOS DE DATA
    * */
    public String getMonth(String name, Context context){
        switch (Integer.parseInt(name)){
            case 0:
                return context.getString(R.string.january);
            case 1:
                return context.getString(R.string.february);
            case 2:
                return context.getString(R.string.march);
            case 3:
                return  context.getString(R.string.april);
            case 4:
                return context.getString(R.string.may);
            case 5:
                return context.getString(R.string.june);
            case 6:
                return context.getString(R.string.july);
            case 7 :
                return context.getString(R.string.august);
            case 8:
                return context.getString(R.string.september);
            case 9:
                return context.getString(R.string.october);
            case 10:
                return context.getString(R.string.november);
            case 11:
                return context.getString(R.string.december);
        }
        return "";
    }
}
