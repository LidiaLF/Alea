package com.example.alea.service;

import android.content.Context;
import android.net.Uri;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.alea.R;
import com.example.alea.activity.MessageActivity;
import com.example.alea.adapter.GlideApp;
import com.example.alea.util.Constant;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;

public class ServiceUser {
    private static ServiceUser mInstance = null;

    public static synchronized ServiceUser getInstance() {
        if (mInstance == null) {
            mInstance = new ServiceUser();
        }
        return mInstance;
    }

    private ServiceUser(){
    }

    public String getKeyCurrentUser(Context context){
        String uid = context.getSharedPreferences(Constant.ALEA_SP, Context.MODE_PRIVATE).getString(Constant.SP_UID, String.valueOf(FirebaseAuth.getInstance().getCurrentUser()));
        return uid;
    }
    public String getCurrentUser(Context context){
        String user = context.getSharedPreferences(Constant.ALEA_SP, Context.MODE_PRIVATE).getString(Constant.SP_USER,  "");
        return user;
    }
    public String getNameCurrentUser(Context context){
        String name = context.getSharedPreferences(Constant.ALEA_SP, Context.MODE_PRIVATE).getString(Constant.SP_NAME, "");
        return name;
    }
    public String getSurnameCurrentUser(Context context){
        String surname = context.getSharedPreferences(Constant.ALEA_SP, Context.MODE_PRIVATE).getString(Constant.SP_SURNAME, "");
        return surname;
    }
    public String getPwdCurrentUser(Context context){
        String pwd = context.getSharedPreferences(Constant.ALEA_SP, Context.MODE_PRIVATE).getString(Constant.SP_PWD,  "");
        return pwd;
    }
    public boolean isWorking(Context context){
        boolean isWorking = context.getSharedPreferences(Constant.ALEA_SP, Context.MODE_PRIVATE).getBoolean(Constant.SP_ISWORKING, false);
        return isWorking;
    }

    public void loadImage(String uid, final Context context, final ImageView bindingIv){
            FirebaseStorage.getInstance().getReference().child(uid).child(Constant.urlFoto)
                    .getDownloadUrl()
                    .addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    String downloadUrl = uri.toString();
                    assert bindingIv != null;
                    GlideApp.with(context).load(downloadUrl)
                            .apply(RequestOptions.circleCropTransform())
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true)
                            .into(bindingIv);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    GlideApp.with(context).load(R.mipmap.ic_sombra)
                            .apply(RequestOptions.circleCropTransform())
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true)
                            .into(bindingIv);
                }
            });

            if(bindingIv == null){
                GlideApp.with(context).load(R.mipmap.ic_sombra)
                        .apply(RequestOptions.circleCropTransform())
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true)
                        .into(bindingIv);
            }
    }
    
}
