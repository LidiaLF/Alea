package com.example.alea.adapter.message;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.alea.R;

public class MessageHolder extends RecyclerView.ViewHolder {

private TextView name;
private TextView message;
private TextView dateMessage;
private ImageView perfilPicture;
private ImageView messagePicture;

public MessageHolder(View itemView) {
        super(itemView);
        name = itemView.findViewById(R.id.tv_nameMessage);
        message = itemView.findViewById(R.id.tv_message);
        dateMessage = itemView.findViewById(R.id.tv_dataMessage);
        perfilPicture = itemView.findViewById(R.id.iv_PerfilPicture);
        messagePicture = itemView.findViewById(R.id.iv_messagePicture);
        }

public TextView getName() {
        return name;
        }

public void setName(TextView name) {
        this.name = name;
        }

public TextView getMessage() {
        return message;
        }

public void setMessage(TextView message) {
        this.message = message;
        }

public TextView getDateMessage() {
        return dateMessage;
        }

public void setDateMessage(TextView dateMessage) {
        this.dateMessage = dateMessage;
        }

public ImageView getPerfilPicture() {
        return perfilPicture;
        }

public void setPerfilPicture(ImageView perfilPicture) {
        this.perfilPicture = perfilPicture;
        }

public ImageView getMessagePicture() {
        return messagePicture;
        }

public void setMessagePicture(ImageView messagePicture) {
        this.messagePicture = messagePicture;
        }

        }
