package com.example.alea.model;

public class Event {
    String id, title, description, time;
    int day, month, year;
    boolean remember;

    public Event(){}
    public Event(String id, int day, int month, int year, String time, String title, String description, boolean remember) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.day = day;
        this.month = month;
        this.year = year;
        this.remember = remember;
        this.time = time;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public boolean isRemember() {
        return remember;
    }

    public void setRemember(boolean remember) {
        this.remember = remember;
    }

    @Override
    public String toString() {
        return "Event{" +
                "idUser='" + id + '\'' +
                ", nameEvent='" + title + '\'' +
                ", descEvent='" + description + '\'' +
                ", day=" + day +
                ", month=" + month +
                ", year=" + year +
                ", REMEMBER" + remember+
                '}';
    }
}
