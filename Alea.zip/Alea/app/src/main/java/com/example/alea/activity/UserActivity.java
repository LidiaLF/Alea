package com.example.alea.activity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.alea.R;
import com.example.alea.databinding.ActivityUserBinding;
import com.example.alea.databinding.NavHeaderMainBinding;
import com.example.alea.service.Service;
import com.example.alea.service.ServiceUser;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    ActivityUserBinding binding;
    NavHeaderMainBinding navBinding;
    ImageView iv;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUserBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        /*
        * BOTÓN FLOTANTE PARA FICHAXES
        * */
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(UserActivity.this, SignActivity.class);
                startActivity(i);
            }
        });

        //loadData();

        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_calendar, R.id.nav_payroll, R.id.nav_aleaGroup, R.id.nav_settings, R.id.nav_closeSesion)
                .setDrawerLayout(binding.drawerLayout)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);

        NavigationUI.setupWithNavController( binding.navView, navController);

        TextView textView = findViewById(R.id.nav_closeSesion);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                finish();
            }
        });

    }

  /*  private void loadData() {
        View header = binding.navView.getHeaderView(0);
        TextView name = header.findViewById(R.id.tv_nameUser);
        TextView status = header.findViewById(R.id.tv_stateNow);
        CircleImageView myStatus = header.findViewById(R.id.iv_myState);
        ImageView myImage = header.findViewById(R.id.iv_myImage);

        ServiceUser.getInstance().loadImage(ServiceUser.getInstance().getKeyCurrentUser(getApplicationContext()), getApplicationContext(), myImage);
        name.setText(ServiceUser.getInstance().getNameCurrentUser(getApplicationContext()).toUpperCase());
        if (ServiceUser.getInstance().isWorking(getApplicationContext())) {
            status.setText(R.string.working);
            myStatus.setImageResource(R.color.green);
        }else{
            status.setText(R.string.offline);
            myStatus.setImageResource(R.color.red);
        }

    }*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.user, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_settings:
                startActivity(new Intent(UserActivity.this,
                        PreferencesActivity.class));
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onResume() {
        super.onResume();
        Service.getInstance().loadLanguage(this);
        //loadData();
    }
}